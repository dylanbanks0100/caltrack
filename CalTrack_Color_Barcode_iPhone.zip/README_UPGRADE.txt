CalTrack upgrade:
• Colorful mobile-first design
• iPhone camera barcode scanning where supported
• Free Open Food Facts UPC lookup
• Shows product name, brand, calories, protein, carbs and fat
• Adds scanned food to the daily log

For iPhone camera access, host the site over HTTPS and allow camera permission.
Open Food Facts is a public database; product data can vary, so verify nutrition labels when needed.
