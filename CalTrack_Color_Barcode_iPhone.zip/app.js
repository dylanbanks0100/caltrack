let state=JSON.parse(localStorage.getItem("caltrackMFP")||"null")||{goal:2000,weight:165,target:150,unit:"imperial",exercise:0,foods:{Breakfast:[],Lunch:[],Dinner:[],Snacks:[]}};
let activeMeal="Breakfast";
const $=id=>document.getElementById(id);
function save(){localStorage.setItem("caltrackMFP",JSON.stringify(state))}
function totals(){let food=0,p=0,c=0,f=0;Object.values(state.foods).flat().forEach(x=>{food+=x.cal;p+=x.p;c+=x.c;f+=x.f});return{food,p,c,f}}
function render(){const t=totals(),rem=Math.max(0,state.goal-t.food+state.exercise);$("goalCal").textContent=state.goal.toLocaleString();$("foodCal").textContent=t.food.toLocaleString();$("exerciseCal").textContent=state.exercise.toLocaleString();$("remaining").textContent=rem.toLocaleString();$("remaining2").textContent=rem.toLocaleString();$("calBar").style.width=Math.min(100,t.food/state.goal*100)+"%";$("exerciseDisplay").textContent=state.exercise+" kcal";
  ["Breakfast","Lunch","Dinner","Snacks"].forEach(meal=>{let a=state.foods[meal],sum=a.reduce((s,x)=>s+x.cal,0);$(meal+"Total").textContent=sum.toLocaleString();$(meal).innerHTML=a.length?a.map((x,i)=>`<div class="food"><div><b>${esc(x.name)}</b><small> • ${x.p}g P · ${x.c}g C · ${x.f}g F</small></div><b>${x.cal}</b><button onclick="removeFood('${meal}',${i})">×</button></div>`).join(""):'<div class="food"><small>No food logged yet</small><span></span><span></span></div>'});
  let macros=[["pText","pBar",t.p,150],["cText","cBar",t.c,200],["fText","fBar",t.f,67]];macros.forEach(([txt,bar,val,target])=>{$(txt).textContent=`${Math.round(val)} / ${target} g`;$(bar).style.width=Math.min(100,val/target*100)+"%"});
  const unit=state.unit==="metric"?"kg":"lb";$("currentWeight").textContent=state.weight+" "+unit;$("targetWeight").textContent=state.target+" "+unit;let diff=Math.abs(state.target-state.weight);$("goalCopy").textContent=diff+" "+unit+" to go";let pct=diff?Math.max(0,Math.min(100,100-(diff/Math.max(diff,Math.abs(state.weight-state.target)+diff))*100)):100;$("goalBar").style.width=pct+"%";$("unitBtn").textContent=state.unit==="metric"?"Metric":"Imperial";$("planWeightUnit").textContent=unit;$("planTargetUnit").textContent=unit;
}
function esc(s){return s.replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function openFood(meal){activeMeal=meal;$("modalTitle").textContent="Add to "+meal;$("foodName").value="";$("foodCalories").value="";$("foodP").value=0;$("foodC").value=0;$("foodF").value=0;$("modal").classList.remove("hidden")}
document.querySelectorAll(".add[data-meal]").forEach(b=>b.onclick=()=>openFood(b.dataset.meal));
$("closeModal").onclick=()=>$("modal").classList.add("hidden");
$("saveFood").onclick=()=>{let name=$("foodName").value.trim(),cal=Number($("foodCalories").value)||0;if(!name||!cal){alert("Enter a food name and calories.");return}state.foods[activeMeal].push({name,cal,p:Number($("foodP").value)||0,c:Number($("foodC").value)||0,f:Number($("foodF").value)||0});save();$("modal").classList.add("hidden");render()};
window.removeFood=(meal,i)=>{state.foods[meal].splice(i,1);save();render()};
$("addExercise").onclick=()=>{let n=prompt("Calories burned:", "300");if(n!==null){state.exercise=Math.max(0,Number(n)||0);save();render()}};
$("clearDay").onclick=()=>{if(confirm("Clear all food and exercise for today?")){Object.keys(state.foods).forEach(k=>state.foods[k]=[]);state.exercise=0;save();render()}};
function openPlan(){ $("newGoal").value=state.goal;$("newWeight").value=state.weight;$("newTarget").value=state.target;$("planModal").classList.remove("hidden")}
$("editPlan").onclick=openPlan;$("goalEdit").onclick=openPlan;$("closePlan").onclick=()=>$("planModal").classList.add("hidden");
$("savePlan").onclick=()=>{state.goal=Math.max(1000,Number($("newGoal").value)||2000);state.weight=Number($("newWeight").value)||state.weight;state.target=Number($("newTarget").value)||state.target;save();$("planModal").classList.add("hidden");render()};
$("unitBtn").onclick=()=>{let old=state.unit;if(old==="imperial"){state.weight=Math.round(state.weight*.453592*10)/10;state.target=Math.round(state.target*.453592*10)/10;state.unit="metric"}else{state.weight=Math.round(state.weight/0.453592*10)/10;state.target=Math.round(state.target/0.453592*10)/10;state.unit="imperial"}save();render()};
render();